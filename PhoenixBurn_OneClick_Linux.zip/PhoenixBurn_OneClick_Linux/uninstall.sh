#!/bin/sh
set -eu
exec sudo apt remove phoenixburn

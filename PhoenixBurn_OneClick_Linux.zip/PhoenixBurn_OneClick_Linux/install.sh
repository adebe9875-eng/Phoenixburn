#!/bin/sh
set -eu
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
DEB="$HERE/PhoenixBurn_Installer_1.0.0_amd64.deb"
if [ "$(uname -s)" != Linux ]; then
    echo 'هذه الحزمة مخصصة لنظام Linux فقط.'
    exit 1
fi
if [ "$(uname -m)" != x86_64 ]; then
    echo 'هذه النسخة مخصصة لمعمارية x86_64 فقط.'
    exit 1
fi
if [ ! -f "$DEB" ]; then
    echo 'لم أجد ملف PhoenixBurn_Installer_1.0.0_amd64.deb بجانب هذا الملف.'
    exit 1
fi
if ! command -v sudo >/dev/null 2>&1; then
    echo 'sudo غير موجود. ثبّت sudo ثم أعد المحاولة.'
    exit 1
fi
exec sudo apt install "$DEB"
